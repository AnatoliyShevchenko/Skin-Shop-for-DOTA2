categories = [
  {
    "name": "Все предметы",
    "img": "https://collectorsshop.ru/img/catalog/menu/arcana.png",
    "number" : 0
  },
  {
    "name": "The International 2022",
    "img": "https://collectorsshop.ru/img/catalog/menu/q2nI6mlQBSgH.png",
    "number" : 1
  },
  {
    "name": "Лабиринт Аганима",
    "img": "https://collectorsshop.ru/img/catalog/menu/t3hXpwMicSY9.png",
    "number" : 2
  },
  {
    "name": "Враждостояние 2021",
    "img": "https://collectorsshop.ru/img/catalog/menu/Pm6L298NVnhZ.png",
    "number" : 3
  },
  {
    "name": "The International 2020",
    "img": "https://collectorsshop.ru/img/catalog/menu/bcI2CYHxJKn1.png",
    "number" : 4
  },
  {
    "name": "The International 2019",
    "img": "https://collectorsshop.ru/img/catalog/menu/kXTZl3m9xwgG.png",
    "number" : 5
  },
  {
    "name": "The International 2018",
    "img": "https://collectorsshop.ru/img/catalog/menu/5x10jLIg3cWE.png",
    "number" : 6
  },
  {
    "name": "Dead Reckoning Chest",
    "img": "https://collectorsshop.ru/img/catalog/menu/LOKISK.png",
    "number" : 7
  },
  {
    "name": "Предметы Immortal",
    "img": "https://collectorsshop.ru/img/catalog/menu/immortal.png",
    "number" : 8
  },
]