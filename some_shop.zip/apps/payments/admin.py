# Django
from django.contrib import admin

# Local
from .models import Payments


admin.site.register(Payments)

